Easy Apply Kit — job-62 — UCSF — Institute for Neurodegenerative Diseases (IND) — Staff Research Associate II — Drug Discovery, HTS team (small-molecule screening; LIVE, Job Code 009617)
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://ind.ucsf.edu/staff-research-associate-ii-drug-discovery
Direct Apply (verified, official ATS only): https://sjobs.brassring.com/TGnewUI/Search/Home/Home?partnerid=6495&siteid=5861#jobDetails=3364720_5861
Channel: Official UCSF careers/BrassRing (direct, UC system)
Match Score: 78%
Flag: BSL 2/3 lab clearance required — UCSF arranges/approves; physical/health screening required per posting.

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-62_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
