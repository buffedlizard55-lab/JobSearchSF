JobSearchSF — Easy Apply Kit
ID: job-37 — job-37
Company: San Francisco Unified School District (SFUSD)
Position: Science Laboratory / Classroom Support (classified staff, e.g., science prep technician)
Location: 555 Franklin Street (admin) + school sites citywide, San Francisco, CA 94102
Match Score: 58%
Status: monitor
Status Note: SFUSD careers + Red Rover board verified live (checked Sept 9, 2026); classified science-support roles post with school-year hiring cycles.
Flag: Exact title varies by school ('Science Technician', 'Lab Assistant', aide roles) — read each posting's site + duties. Requires working with students + background clearance. Red Rover is SFUSD's official hiring system (like Workday), not a third-party recruiter.
Verification: Official careers.sfusd.edu → Red Rover official ATS verified + 555 Franklin admin verified

Official Site: https://careers.sfusd.edu/
Direct Apply (official, no recruiter): #
Channel: Official SFUSD applicant system Red Rover (direct district hiring, not a recruiter)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-37_resume.pdf / .docx / .txt
   - Cover: job-37_cover.pdf / .docx / .txt
   - Email: job-37_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://careers.sfusd.edu/
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
