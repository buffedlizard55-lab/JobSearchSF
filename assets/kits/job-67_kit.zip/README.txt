JobSearchSF — Easy Apply Kit
ID: job-67 — job-67
Company: UCSF — Staff Research Associate, Parnassus biomedical lab (cardiovascular/immunotherapy mouse models)
Position: Staff Research Associate — Molecular biology + mouse colony support (LIVE; Parnassus 94143)
Location: UCSF Parnassus Heights (500 Parnassus Ave area), San Francisco, CA 94143
Match Score: 64%
Status: monitor
Status Note: Confirmed live via official careers.ucsf.edu in Sept 9, 2026 snapshot — postings rotate fast; re-search 'Staff Research Associate' + Parnassus and confirm the current JobDetail before applying.
Flag: Live-verified via official-portal snapshot; exact JobDetail ID rotates — confirm at apply time. Mouse colony work is central.
Verification: LIVE SRA posting for 500 Parnassus Ave (94143) confirmed via official careers.ucsf.edu (JobDetail pattern) in Sept 9, 2026 snapshot — confirm exact JobDetail ID before applying

Official Site: https://careers.ucsf.edu
Direct Apply (official, no recruiter): #
Channel: Official UCSF careers portal (direct, UC system)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-67_resume.pdf / .docx / .txt
   - Cover: job-67_cover.pdf / .docx / .txt
   - Email: job-67_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://careers.ucsf.edu
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
