JobSearchSF — Easy Apply Kit
ID: job-71 — job-71
Company: EVERY (The EVERY Company) — precision fermentation, animal-free protein ingredients
Position: Research Associate I (Protein Science & Analytics) — HPLC, FPLC, plate readers (LIVE; $75-85K)
Location: San Francisco, CA (official board location; HQ 689 Bryant St, 94107 area — confirm building at interview)
Match Score: 88%
Status: recently-posted
Status Note: Live on official Greenhouse board (checked Sept 9, 2026) — the only current EVERY opening; re-verify the job ID is live before applying.
Flag: Older 'Research Associate I' posting (job 5217382004) is closed — use 5745371004 only. Street address (689 Bryant St HQ area) confirmed at interview.
Verification: LIVE official Greenhouse posting (job 5745371004) fetched Sept 9, 2026 — 'San Francisco, California, United States', $75,000-$85,000; every.com official company site verified

Official Site: https://job-boards.greenhouse.io/theeverycompany/jobs/5745371004
Direct Apply (official, no recruiter): #
Channel: Official EVERY Greenhouse board (direct employer, B2B food-tech ingredient company)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-71_resume.pdf / .docx / .txt
   - Cover: job-71_cover.pdf / .docx / .txt
   - Email: job-71_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://job-boards.greenhouse.io/theeverycompany/jobs/5745371004
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
