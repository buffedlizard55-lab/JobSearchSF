JobSearchSF — Easy Apply Kit
ID: job-115 — job-115
Company: City & County of San Francisco - Department of Public Health (class 2416)
Position: Laboratory Technician II (2416) - SFDPH Public Health Laboratory, 101 Grove St (position-based test)
Location: 101 Grove Street, San Francisco, CA 94102 (Public Health Laboratory, SFDPH)
Match Score: 86%
Status: monitor
Status Note: Last City announcement for this exact posting opened Sep 13, 2023 and finally closed Sep 22, 2023, so there is no open filing window on 2026-09-09 - the role page stays published and states the eligible list 'may be used to fill future vacancies in this class' (Rule of 3). Salary shown on the class header: $81,692-$99,372; the 2023 announcement text printed $73,398-$89,336 for the common range at that time. Watch the class page and apply inside the first days of any new window.
Flag: Civil-service mechanics: this is a position-based test for a specific vacancy, so you compete for the open seat rather than landing on a general list; the announcement also directs applicants to a required supplemental questionnaire (the 2023 posting linked an MS Form). A department contact is printed on the City page (Hanz Pagao, hanz.pagao@sfdph.org) - use it only to ask about the qualification review, never to apply outside the portal.
Verification: careers.sf.gov role page 'Laboratory Technician II (2416) - DPH - 139184' (id 3743990002599958) fetched in full on 2026-09-09 - duties, minimum quals, location, shift, salary and department contact read off the City's own page

Official Site: https://careers.sf.gov/classifications/?classCode=2416
Direct Apply (official, no recruiter): #
Channel: Official City & County of San Francisco portal - direct civil-service hire, position-based test, never through a staffing firm

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-115_resume.pdf / .docx / .txt
   - Cover: job-115_cover.pdf / .docx / .txt
   - Email: job-115_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://careers.sf.gov/classifications/?classCode=2416
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
