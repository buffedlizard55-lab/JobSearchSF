Easy Apply Kit — job-115 — City & County of San Francisco - Department of Public Health (class 2416) — Laboratory Technician II (2416) - SFDPH Public Health Laboratory, 101 Grove St (position-based test)
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://careers.sf.gov/classifications/?classCode=2416
Direct Apply (verified, official ATS only): https://careers.sf.gov/role/?id=3743990002599958
Channel: Official City & County of San Francisco portal - direct civil-service hire, position-based test, never through a staffing firm
Match Score: 86%
Flag: Civil-service mechanics: this is a position-based test for a specific vacancy, so you compete for the open seat rather than landing on a general list; the announcement also directs applicants to a required supplemental questionnaire (the 2023 posting linked an MS Form). A department contact is printed on the City page (Hanz Pagao, hanz.pagao@sfdph.org) - use it only to ask about the qualification review, never to apply outside the portal.

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-115_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
