JobSearchSF — Easy Apply Kit
ID: job-43 — job-43
Company: City & County of San Francisco — SFDPH / Citywide Labs
Position: Laboratory Technician I (Class 2402) — Entry lab support (glassware, media, inventory, records)
Location: Citywide — SFDPH Public Health Laboratories & City clinics (duty station per posting; HQ 101 Grove St), San Francisco
Match Score: 80%
Status: monitor
Status Note: Class 2402 spec verified live (checked Sept 9, 2026); entrance exams post as needed — watch careers.sf.gov for 2402 announcements.
Flag: Entry rung is routine by design (glassware, media, inventory) — a foot-in-the-door, not a chemist role; promotes to 2416 Laboratory Technician II.
Verification: Official careers.sf.gov classification 2402 spec verified ($72K-$88K/yr, no license, promotes to 2416)

Official Site: https://careers.sf.gov/classifications/?classCode=2402
Direct Apply (official, no recruiter): #
Channel: Official City & County of SF portal (direct civil service)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-43_resume.pdf / .docx / .txt
   - Cover: job-43_cover.pdf / .docx / .txt
   - Email: job-43_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://careers.sf.gov/classifications/?classCode=2402
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
