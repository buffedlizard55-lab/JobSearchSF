JobSearchSF — Easy Apply Kit
ID: job-80 — job-80
Company: Deciduous Therapeutics (DTx) — drug discovery startup
Position: Senior Research Associate — Immunology (LIVE; $80-120K) [FLAG: senior level — M.S./PhD preferred]
Location: 953 Indiana Street, San Francisco, CA 94107 (Dogpatch)
Match Score: 55%
Status: monitor
Status Note: Live 'Senior Research Associate – Immunology' confirmed Sept 9, 2026 — re-verify the req + level requirements on deciduoustx.com careers before applying.
Flag: Senior-level posting (M.S./PhD preferred) — speculative apply for a B.S.; company, address, and role are all verified.
Verification: LIVE 'Senior Research Associate – Immunology' (SF 94107, $80-120K) confirmed via official deciduoustx.com careers + company records (953 Indiana St, 94107; biospace employer page) Sept 9, 2026

Official Site: https://www.deciduoustx.com/
Direct Apply (official, no recruiter): #
Channel: Official Deciduous Therapeutics site/careers email (direct startup employer — same 953 Indiana St shared lab building as Wildtype, job-55)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-80_resume.pdf / .docx / .txt
   - Cover: job-80_cover.pdf / .docx / .txt
   - Email: job-80_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://www.deciduoustx.com/
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
