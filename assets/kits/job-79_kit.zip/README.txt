JobSearchSF — Easy Apply Kit
ID: job-79 — job-79
Company: Invitae (a Labcorp company) — clinical genetics
Position: Clinical Lab Technician — Entry level, genetics lab (LIVE; Sun-Thu 3:00pm-11:30pm; $28.39-35/hr)
Location: 1400 16th Street, San Francisco, CA 94103 (Mission)
Match Score: 62%
Status: recently-posted
Status Note: Live via official Labcorp careers channel (checked Sept 9, 2026) — re-verify the req is open before applying; distinct from job-32 (Lab Assistant, 6 SF sites incl. 148 Noe St).
Flag: Evening shift (Sun-Thu 3:00pm-11:30pm) — plan your schedule around it.
Verification: LIVE 'Clinical Lab Technician - Invitae - Entry level' (1400 16th St, Sun-Thu 3:00pm-11:30pm, $28.39-35/hr) confirmed via official Labcorp careers channel (careers.labcorp.com) Sept 9, 2026; invitae.com official

Official Site: https://www.invitae.com/
Direct Apply (official, no recruiter): #
Channel: Official Labcorp careers portal (Invitae is a Labcorp company — direct employer, not a recruiter; see also job-32)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-79_resume.pdf / .docx / .txt
   - Cover: job-79_cover.pdf / .docx / .txt
   - Email: job-79_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://www.invitae.com/
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
