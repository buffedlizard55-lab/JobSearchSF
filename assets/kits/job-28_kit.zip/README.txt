Easy Apply Kit — job-28 — Chinese Hospital — Clinical Laboratory (Chinatown main campus) — Clinical Laboratory Technician (Non-Testing Personnel) — specimen collection & lab support
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://chinesehospital-sf.org/job-opportunities/
Direct Apply (verified, official ATS only): https://chinesehospital-sf.org/job/clinicallabtech/
Channel: Official hospital website application (direct, no recruiter)
Match Score: 48%
Flag: REQUIRES California CPT-1/CPT-2 phlebotomy license — do not apply without it (or while in a CPT program). Also requires nights/weekends/holiday availability. Sunset clinic (1800 31st Ave, 94122) is in your zip but main lab is Chinatown.

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-28_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
