JobSearchSF — Easy Apply Kit
ID: job-36 — job-36
Company: UCSF Health Hyde Hospital (formerly Saint Francis Memorial)
Position: Laboratory Assistant — Clinical Lab Support (entry, non-licensed)
Location: 900 Hyde Street (between Bush & Pine, Nob Hill), San Francisco, CA 94109
Match Score: 64%
Status: monitor
Status Note: UCSF Health portal verified; Hyde lab-support roles post periodically — search hospital name on the portal.
Flag: Hospital renamed: apply via UCSF Health portal (jobs.ucsfmedicalcenter.org), NOT Dignity/CommonSpirit boards. CLS/MLT roles require CA license — target Lab Assistant titles.
Verification: Official sfcommunityhospitals.ucsfhealth.org confirms UCSF Health acquisition + 900 Hyde address

Official Site: https://sfcommunityhospitals.ucsfhealth.org/saint-francis
Direct Apply (official, no recruiter): #
Channel: Official UCSF Health portal (direct) — hospital is now UCSF Health, not Dignity

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-36_resume.pdf / .docx / .txt
   - Cover: job-36_cover.pdf / .docx / .txt
   - Email: job-36_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://sfcommunityhospitals.ucsfhealth.org/saint-francis
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
