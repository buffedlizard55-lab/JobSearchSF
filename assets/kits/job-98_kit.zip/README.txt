Easy Apply Kit — job-98 — BridgeBio Pharma — Analytical Development (Drug substance/product) — Sr Manager, Analytical Development — SF (HPLC LC/MS GC GC/MS ICH QMS Veeva Vault stability OOS; LIVE 5222895007 $175-185K)
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://bridgebio.com/careers/
Direct Apply (verified, official ATS only): https://job-boards.greenhouse.io/bridgebio/jobs/5222895007
Channel: Official BridgeBio Greenhouse board (direct)
Match Score: 80%
Flag: Senior-level Sr Manager — 7-10 yrs experience required; speculative for B.S. but posting verified.

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-98_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
