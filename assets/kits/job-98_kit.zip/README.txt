JobSearchSF — Easy Apply Kit
ID: job-98 — job-98
Company: BridgeBio Pharma — Analytical Development (Drug substance/product)
Position: Sr Manager, Analytical Development — SF (HPLC LC/MS GC GC/MS ICH QMS Veeva Vault stability OOS; LIVE 5222895007 $175-185K)
Location: 1800 Owens Street, San Francisco, CA 94158 (Mission Bay / Dogpatch)
Match Score: 80%
Status: recently-posted
Status Note: LIVE verified on job-boards.greenhouse.io/bridgebio/jobs/5222895007 (checked Sept 2026) — $175-185K SF.
Flag: Senior-level Sr Manager — 7-10 yrs experience required; speculative for B.S. but posting verified.
Verification: LIVE Greenhouse job 5222895007 fetched Sept 2026 — 1800 Owens St SF 94158, $175-185K

Official Site: https://bridgebio.com/careers/
Direct Apply (official, no recruiter): #
Channel: Official BridgeBio Greenhouse board (direct)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-98_resume.pdf / .docx / .txt
   - Cover: job-98_cover.pdf / .docx / .txt
   - Email: job-98_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://bridgebio.com/careers/
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
