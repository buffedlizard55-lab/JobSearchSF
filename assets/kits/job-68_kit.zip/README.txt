JobSearchSF — Easy Apply Kit
ID: job-68 — job-68
Company: HHMI — Brainard Lab (UCSF Physiology & Psychiatry)
Position: Research Technician I/II — Behavioral neuroscience, songbird model (LIVE req R-4026)
Location: 1550 4th Street, Suite 190 (Molecular Bioscience Complex, UCSF Mission Bay), San Francisco, CA 94158
Match Score: 62%
Status: recently-posted
Status Note: Live on official HHMI Workday (checked Sept 9, 2026) — posted Jan 2026, still open; lab site brainardlab.ucsf.edu for details.
Flag: Songbird (bird) model, not rodent; role may include stereotaxic surgery and viral-construct injection work.
Verification: LIVE req R-4026 fetched from official hhmi.wd1.myworkdayjobs.com (Sept 9, 2026): work address 1550 4th St Ste 190, SF 94158; RT I $20.08-32.65/hr, RT II $24-39/hr; hhmi.org scientist profile verified

Official Site: https://hhmi.wd1.myworkdayjobs.com/en-US/External/job/Research-Technician--Brainard-Lab_R-4026-1
Direct Apply (official, no recruiter): #
Channel: Official HHMI Workday portal (HHMI is employer of record for this UCSF lab — direct, not a recruiter)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-68_resume.pdf / .docx / .txt
   - Cover: job-68_cover.pdf / .docx / .txt
   - Email: job-68_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://hhmi.wd1.myworkdayjobs.com/en-US/External/job/Research-Technician--Brainard-Lab_R-4026-1
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
