JobSearchSF — Easy Apply Kit
ID: job-117 — job-117
Company: City & County of San Francisco - Department of Public Health (class 2463)
Position: Microbiologist I (2463) - SFDPH Public Health Laboratory - QUALIFICATION GAP, do not apply yet
Location: San Francisco Public Health Laboratories, Department of Public Health, San Francisco
Match Score: 34%
Status: flag
Status Note: Listed deliberately as a blocked row so the requirement is visible instead of rediscovered in three months: the last City window for this posting ran Apr 25 - Jun 8, 2023 (class range $104,806-$182,936; the 2023 announcement printed $91,910-$129,402, steps 1-8, variable shifts), and the qualification screen would have excluded this application. To make this real you would need microbiology course work and the state certificate; the 2416 Laboratory Technician II class (job-115) is the same building and same lab without that gate.
Flag: Not eligible as the record stands - B.S. Chemistry (UCSC 2011) is not a microbiology major and no CA public health microbiologist certificate is held. Do not apply to 2463 postings until that changes; do not let an agent or a 'we can get you around the certificate' offer touch this - both are disqualifiers and a scam tell.
Verification: careers.sf.gov role page 'Microbiologist I - 2463 - Department of Public Health' (id 3743990001679838, REF26033Y / PBT-2463-134715) fetched in full on 2026-09-09; minimum qualifications, compensation and dates quoted from the City's own page

Official Site: https://careers.sf.gov/classifications/?classCode=2463
Direct Apply (official, no recruiter): #
Channel: Official City & County of San Francisco portal (position-based test, Rule of 3)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-117_resume.pdf / .docx / .txt
   - Cover: job-117_cover.pdf / .docx / .txt
   - Email: job-117_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://careers.sf.gov/classifications/?classCode=2463
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
