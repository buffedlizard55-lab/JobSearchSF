JobSearchSF — Easy Apply Kit
ID: job-72 — job-72
Company: General Proximity — induced proximity medicines (OmniTAC engine)
Position: Research Associate, Drug Discovery — Platform/Discovery team (LIVE; $32-45/hr)
Location: 135 Mississippi Street (MBC BioLabs, Potrero Hill), San Francisco, CA 94107
Match Score: 72%
Status: recently-posted
Status Note: Live on official Greenhouse board (checked Sept 9, 2026) — re-verify job 5660523004 is open before applying; $32-45/hr + equity per posting.
Flag: None — no irregularity found at audit; re-verify live before applying
Verification: LIVE official Greenhouse posting (job 5660523004) fetched Sept 9, 2026 — MBC BioLabs at 135 Mississippi St, 'short walk from the 22nd St Caltrain Station' per posting

Official Site: https://job-boards.greenhouse.io/generalproximity/jobs/5660523004
Direct Apply (official, no recruiter): #
Channel: Official General Proximity Greenhouse board (direct startup employer)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-72_resume.pdf / .docx / .txt
   - Cover: job-72_cover.pdf / .docx / .txt
   - Email: job-72_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://job-boards.greenhouse.io/generalproximity/jobs/5660523004
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
