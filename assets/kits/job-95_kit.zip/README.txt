Easy Apply Kit — job-95 — Capable — Peptide therapeutics (Founding team, Harvard/MIT advisors, $12M pre-seed) — Founding Chemist — Fmoc SPPS Liberty Blue, Agilent 1260/1290 prep HPLC, Agilent 6530 LCMS, mouse dosing PK (LIVE Ashby 2ab44b1b $120-180K)
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://jobs.ashbyhq.com/Capable/2ab44b1b-629f-4492-99ff-bcebae57e15b
Direct Apply (verified, official ATS only): https://jobs.ashbyhq.com/Capable/2ab44b1b-629f-4492-99ff-bcebae57e15b
Channel: Official Capable Ashby board (direct startup employer)
Match Score: 94%
Flag: Early-stage startup — high-velocity (79 syntheses/6 months); street address confirmed at interview.

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-95_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
