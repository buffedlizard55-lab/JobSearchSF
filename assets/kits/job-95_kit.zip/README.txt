JobSearchSF — Easy Apply Kit
ID: job-95 — job-95
Company: Capable — Peptide therapeutics (Founding team, Harvard/MIT advisors, $12M pre-seed)
Position: Founding Chemist — Fmoc SPPS Liberty Blue, Agilent 1260/1290 prep HPLC, Agilent 6530 LCMS, mouse dosing PK (LIVE Ashby 2ab44b1b $120-180K)
Location: San Francisco, CA (SF per official posting; street address confirmed at interview)
Match Score: 94%
Status: recently-posted
Status Note: LIVE verified on jobs.ashbyhq.com/Capable/2ab44b1b-629f-4492-99ff-bcebae57e15b (checked Sept 2026) — $120-180K + equity; early-stage.
Flag: Early-stage startup — high-velocity (79 syntheses/6 months); street address confirmed at interview.
Verification: LIVE Ashby posting 2ab44b1b fetched Sept 2026 — $120-180K, SF, 270+ candidates 72+ mouse trials 79 syntheses in 6 months, $10k referral

Official Site: https://jobs.ashbyhq.com/Capable/2ab44b1b-629f-4492-99ff-bcebae57e15b
Direct Apply (official, no recruiter): #
Channel: Official Capable Ashby board (direct startup employer)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-95_resume.pdf / .docx / .txt
   - Cover: job-95_cover.pdf / .docx / .txt
   - Email: job-95_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://jobs.ashbyhq.com/Capable/2ab44b1b-629f-4492-99ff-bcebae57e15b
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
