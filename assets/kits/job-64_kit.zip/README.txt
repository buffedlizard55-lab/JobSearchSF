JobSearchSF — Easy Apply Kit
ID: job-64 — job-64
Company: UCSF — Goodarzi Lab, Biochemistry & Biophysics
Position: Junior Specialist — RNA-based therapeutics & cancer biology (JPF06054, LIVE, posted Apr 2026)
Location: UCSF Parnassus Heights (Biochemistry & Biophysics, 400 Parnassus Ave area), San Francisco, CA 94143
Match Score: 70%
Status: recently-posted
Status Note: Live on apprecruit.ucsf.edu (checked Sept 9, 2026), final date Oct 27, 2027; companion posting JPF05571 (Junior/Assistant Specialist, RNA delivery/cancer) open until Oct 25, 2026.
Flag: Mouse work is required (tumor cell injections, tissue harvesting) — posting states 'willingness to work with mice'.
Verification: LIVE posting JPF06054 fetched from official aprecruit.ucsf.edu (Sept 9, 2026): posted Apr 27, 2026, final date Oct 27, 2027, $55,000-$58,600

Official Site: https://aprecruit.ucsf.edu/JPF06054
Direct Apply (official, no recruiter): #
Channel: Official UCSF academic recruit portal aprecruit.ucsf.edu (direct)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-64_resume.pdf / .docx / .txt
   - Cover: job-64_cover.pdf / .docx / .txt
   - Email: job-64_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://aprecruit.ucsf.edu/JPF06054
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
