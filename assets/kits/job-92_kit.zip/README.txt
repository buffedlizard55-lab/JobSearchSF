JobSearchSF — Easy Apply Kit
ID: job-92 — job-92
Company: City & County of San Francisco — Public Utilities Commission / Citywide Labs
Position: Chemist (Class 2486) — Citywide (Water quality, GC-MS, ICP-AES/ICP-MS, LIMS, TNI QC; LIVE REF60430L U00049 $104,806-$147,524)
Location: SFPUC Water Quality / Citywide labs, San Francisco (525 Golden Gate Ave admin + Southeast treatment lab per class)
Match Score: 92%
Status: monitor
Status Note: Window CLOSED: the careers.sf.gov announcement for Chemist (2486) citywide exam REF60430L (U00049) opened Mon Apr 27, 2026 and closed 11:59 pm Fri May 8, 2026 - confirmed on the role page on 2026-09-09, including the City's 05/04/2026 correction note. Salary printed on the page: $104,806-$147,524. The eligible list lasts 12 months and may be extended; the next exam cycle is what to watch for.
Flag: Two corrections on this row: (1) Pass 5 called it LIVE - the filing deadline passed two months before this audit. (2) The old fit text implied GC-MS, ICP-MS and LIMS were skills you have; on the City page those are DESIRABLE qualifications, not minimums, and your background is HPLC/UV-Vis/NMR plus wet chemistry. Apply on the minimums and say you will train on GC/ICP.
Verification: LIVE City posting REF60430L U00049 fetched Sept 2026 — Published May 4 2026 Deadline May 8 2026 11:59 PM PST, $104,806-$147,524 Annual, B.S. Chemistry + GC-MS/ICP-MS/HPLC/LIMS

Official Site: https://careers.sf.gov/classifications/?classCode=2486
Direct Apply (official, no recruiter): #
Channel: Official City & County of SF portal (direct civil service, SmartRecruiters)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-92_resume.pdf / .docx / .txt
   - Cover: job-92_cover.pdf / .docx / .txt
   - Email: job-92_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://careers.sf.gov/classifications/?classCode=2486
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
