Easy Apply Kit — job-92 — City & County of San Francisco — Public Utilities Commission / Citywide Labs — Chemist (Class 2486) — Citywide (Water quality, GC-MS, ICP-AES/ICP-MS, LIMS, TNI QC; LIVE REF60430L U00049 $104,806-$147,524)
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://careers.sf.gov/classifications/?classCode=2486
Direct Apply (verified, official ATS only): https://careers.sf.gov/role/?id=3743990012833986
Channel: Official City & County of SF portal (direct civil service, SmartRecruiters)
Match Score: 92%
Flag: Two corrections on this row: (1) Pass 5 called it LIVE - the filing deadline passed two months before this audit. (2) The old fit text implied GC-MS, ICP-MS and LIMS were skills you have; on the City page those are DESIRABLE qualifications, not minimums, and your background is HPLC/UV-Vis/NMR plus wet chemistry. Apply on the minimums and say you will train on GC/ICP.

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-92_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
