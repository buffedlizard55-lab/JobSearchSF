JobSearchSF — Easy Apply Kit
ID: job-101 — job-101
Company: University of California, San Francisco - Liver Center / Medicine (Maher Lab)
Position: Junior Specialist - Liver cell isolation, analysis & immunology core (JPF06065)
Location: UCSF, San Francisco (Mission Bay campus - see posting for building/room)
Match Score: 92%
Status: recently-posted
Status Note: Application window: open May 1, 2026; review May 16, 2026 (past - still reviewed while unfilled); applications accepted until Nov 1, 2027 (as printed on the official posting list, 2026-09-09). Verified by fetching the posting page itself. The posting's own apply link points to aprecruit.ucsf.edu/JPF06025 for the same recruitment - use the JPF06065 page if the JPF06025 link does not resolve. A reasonable estimate published with the posting: $55,000-$58,600 (UC Table 24B estimate printed on the posting).
Flag: Occasional nights/weekends required (human liver availability); confirm the schedule fits your needs.
Verification: Official UCSF AP Recruit posting page JPF06065 (fetched 2026-09-09)

Official Site: https://aprecruit.ucsf.edu/JPF06065
Direct Apply (official, no recruiter): #
Channel: UCSF Academic Personnel portal (direct hire, no recruiter). Create an AP Recruit account, upload CV + cover letter, and enter reference contacts. No fee, no third party.

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-101_resume.pdf / .docx / .txt
   - Cover: job-101_cover.pdf / .docx / .txt
   - Email: job-101_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://aprecruit.ucsf.edu/JPF06065
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
