JobSearchSF — Easy Apply Kit
ID: job-116 — job-116
Company: City & County of San Francisco - class 2402 Laboratory Technician I
Position: Laboratory Technician I (2402) - entry-level City lab class (general window - watch the class page)
Location: City departments that hire class 2402 (SFDPH Public Health Laboratory, 101 Grove St; other City labs as assigned)
Match Score: 80%
Status: monitor
Status Note: No open general filing window on 2026-09-09. The only live 2402 role page the City is serving (id 743999809251111, published Mar 3, 2022, recruitment REF3136I, salary $72,332-$87,906) is an Access to City Employment (ACE) exam - see the flag. Check the class page weekly; the City re-posts 2402 exams periodically and the ACE channel recurs too.
Flag: IMPORTANT eligibility catch found while verifying: the 2402 page currently published is an ACE recruitment, which hires people with a disability and requires either a Certification of Disability from the California Department of Rehabilitation or a Veterans Preference Letter from the U.S. Department of Veterans Affairs. If you do not have one of those, do not apply through that announcement - wait for a general 2402 exam. Applying to the wrong channel wastes the window.
Verification: careers.sf.gov class-2402 role page (id 743999809251111) fetched in full on 2026-09-09; class definition, minimum qualifications and the $72,332-$87,906 salary range are quoted from the City's own page, alongside the classification page

Official Site: https://careers.sf.gov/classifications/?classCode=2402
Direct Apply (official, no recruiter): #
Channel: Official City & County of San Francisco portal (direct; entry-level class)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-116_resume.pdf / .docx / .txt
   - Cover: job-116_cover.pdf / .docx / .txt
   - Email: job-116_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://careers.sf.gov/classifications/?classCode=2402
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
