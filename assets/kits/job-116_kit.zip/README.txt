Easy Apply Kit — job-116 — City & County of San Francisco - class 2402 Laboratory Technician I — Laboratory Technician I (2402) - entry-level City lab class (general window - watch the class page)
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://careers.sf.gov/classifications/?classCode=2402
Direct Apply (verified, official ATS only): https://careers.sf.gov/classifications/?classCode=2402
Channel: Official City & County of San Francisco portal (direct; entry-level class)
Match Score: 80%
Flag: IMPORTANT eligibility catch found while verifying: the 2402 page currently published is an ACE recruitment, which hires people with a disability and requires either a Certification of Disability from the California Department of Rehabilitation or a Veterans Preference Letter from the U.S. Department of Veterans Affairs. If you do not have one of those, do not apply through that announcement - wait for a general 2402 exam. Applying to the wrong channel wastes the window.

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-116_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
