JobSearchSF — Easy Apply Kit
ID: job-88 — job-88
Company: Pendulum Therapeutics — Microbiome therapeutics (medical probiotics)
Position: Senior Manager, R&D — Microbiome R&D, CRO management, AI/ML data (LIVE Lever f4ea5cbc-34a6-49c3-901c-30a502bcd926)
Location: 933 20th Street, San Francisco, CA 94107 (Potrero Hill / Dogpatch edge)
Match Score: 60%
Status: recently-posted
Status Note: LIVE verified on jobs.lever.co/pendulum/f4ea5cbc-34a6-49c3-901c-30a502bcd926 (checked Sept 2026).
Flag: Senior-level manager — PhD + 5-7 yrs required; speculative apply; posting verified live.
Verification: LIVE Lever job f4ea5cbc-34a6-49c3-901c-30a502bcd926 fetched Sept 2026 — 933 20th St SF 94107, PhD micro/immuno/biochem +5-7 yrs

Official Site: https://pendulum.co
Direct Apply (official, no recruiter): #
Channel: Official Pendulum Lever board (direct, no recruiter)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-88_resume.pdf / .docx / .txt
   - Cover: job-88_cover.pdf / .docx / .txt
   - Email: job-88_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://pendulum.co
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
