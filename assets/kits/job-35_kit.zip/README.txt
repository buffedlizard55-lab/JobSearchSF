JobSearchSF — Easy Apply Kit
ID: job-35 — job-35
Company: Laguna Honda Hospital & Rehabilitation Center (City/DPH)
Position: Laboratory / Clinical Support (hospital lab assistant & aide roles)
Location: 375 Laguna Honda Boulevard, San Francisco, CA 94116 (Forest Hill)
Match Score: 64%
Status: monitor
Status Note: City-run hospital verified; lab-support postings appear on careers.sf.gov periodically — search facility name weekly.
Flag: Clinical Lab Scientist roles require CA CLS license — target Lab Technician/Assistant/Aide titles. Hospital roles may require TB screening, N95 fit testing, vaccines.
Verification: Official sf.gov location page (375 Laguna Honda Blvd) + City-run hospital → careers.sf.gov

Official Site: https://www.sf.gov/location--laguna-honda-hospital-and-rehabilitation-center
Direct Apply (official, no recruiter): #
Channel: Official City & County of SF portal (direct civil service)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-35_resume.pdf / .docx / .txt
   - Cover: job-35_cover.pdf / .docx / .txt
   - Email: job-35_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://www.sf.gov/location--laguna-honda-hospital-and-rehabilitation-center
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
