JobSearchSF — Easy Apply Kit
ID: job-120 — job-120
Company: Addition Therapeutics, Inc. (in vivo cell therapy)
Position: Research Associate / Senior Research Associate - RNA process development & manufacturing (South San Francisco)
Location: South San Francisco, CA (per the employer's own board - not San Francisco)
Match Score: 78%
Status: monitor
Status Note: Live posting verified 2026-09-09; excluded from the target list on location (South San Francisco), not on fit. Strongest single alternate in this pass if the SF-only rule ever relaxes.
Flag: Location rule + '2-4 years' bench expectation: your paid lab terms total roughly a year plus UCSF-era research - address that gap in the letter rather than inflating it.
Verification: Addition Therapeutics official Greenhouse board API listing fetched 2026-09-09: req 57 'Research Associate RA/Sr. RA - RNA Process Development and Manufacturing' (job 5208635007), location 'South San Francisco', first published 2026-08-10, updated 2026-08-17

Official Site: https://job-boards.greenhouse.io/additiontherapeutics
Direct Apply (official, no recruiter): #
Channel: Official employer board (Greenhouse), direct hire - no recruiter

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-120_resume.pdf / .docx / .txt
   - Cover: job-120_cover.pdf / .docx / .txt
   - Email: job-120_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://job-boards.greenhouse.io/additiontherapeutics
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
