JobSearchSF — Easy Apply Kit
ID: job-96 — job-96
Company: UCSF — Abrahamsson Lab, Pharmaceutical Chemistry (Mission Bay)
Position: Research Assistant — Computational Chemistry Junior Specialist (Quantum chem Psi4/ORCA/Gaussian, MD GROMACS/AMBER, Python PyTorch; LIVE JPF06142 $55-58.6K)
Location: 1550 4th Street (UCSF Mission Bay), San Francisco, CA 94158
Match Score: 86%
Status: recently-posted
Status Note: LIVE verified on aprecruit.ucsf.edu/JPF06142 (checked Sept 2026) — open July 9 2026 final Jan 9 2028 $55-58.6K part-time.
Flag: None — no irregularity found at audit; re-verify live before applying
Verification: LIVE aprecruit posting JPF06142 fetched Sept 2026 — Mission Bay 1550 4th St, $55-58.6K, quantum chem + MD + ML

Official Site: https://aprecruit.ucsf.edu/JPF06142
Direct Apply (official, no recruiter): #
Channel: Official UCSF aprecruit portal (direct, UC system)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-96_resume.pdf / .docx / .txt
   - Cover: job-96_cover.pdf / .docx / .txt
   - Email: job-96_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://aprecruit.ucsf.edu/JPF06142
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
