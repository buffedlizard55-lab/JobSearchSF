JobSearchSF — Easy Apply Kit
ID: job-108 — job-108
Company: University of California, San Francisco - Anatomy (Feinberg Lab)
Position: Junior Specialist - Biomaterials and cell-based assays (JPF06049)
Location: UCSF, San Francisco (Mission Bay campus - see posting for building/room)
Match Score: 74%
Status: recently-posted
Status Note: Application window: open Apr 29, 2026; review May 14, 2026 (past - reviewed while unfilled); applications accepted until Oct 29, 2027 (as printed on the official posting list, 2026-09-09).
Flag: None — no irregularity found at audit; re-verify live before applying
Verification: Official UCSF AP Recruit open-recruitments list aprecruit.ucsf.edu/apply (fetched 2026-09-09) - JPF06049 listed with open date Apr 29, 2026

Official Site: https://aprecruit.ucsf.edu/JPF06049
Direct Apply (official, no recruiter): #
Channel: UCSF Academic Personnel portal (direct hire, no recruiter). Create an AP Recruit account, upload CV + cover letter, and enter reference contacts. No fee, no third party.

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-108_resume.pdf / .docx / .txt
   - Cover: job-108_cover.pdf / .docx / .txt
   - Email: job-108_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://aprecruit.ucsf.edu/JPF06049
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
