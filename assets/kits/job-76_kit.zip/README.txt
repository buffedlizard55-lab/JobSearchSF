JobSearchSF — Easy Apply Kit
ID: job-76 — job-76
Company: GLIDE — community health nonprofit (Tenderloin, serving SF since 1963)
Position: Lab Technician — HEAT testing: phlebotomy, CLIA testing, specimen processing (LIVE; $31-33/hr)
Location: 330 Ellis Street (Main Building, Tenderloin), San Francisco, CA 94102 (per official contact page; HEAT team work site confirmed at hiring)
Match Score: 60%
Status: recently-posted
Status Note: Live on official Lever board (checked Sept 9, 2026) — re-verify before applying; GLIDE buildings are in the Tenderloin (open-door community site per posting).
Flag: CLIA-testing + counseling role — BLS required and CA HIV counselor cert must be held or obtained within 6 months; CPhT/MLT a plus, not required.
Verification: LIVE 'Lab Technician' on official Lever board jobs.lever.co/glide fetched Sept 9, 2026 ($31-33/hr, full job description); glide.org/contact official page confirms 330 Ellis St Main Building, 94102

Official Site: https://jobs.lever.co/glide
Direct Apply (official, no recruiter): #
Channel: Official GLIDE Lever board (direct nonprofit employer)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-76_resume.pdf / .docx / .txt
   - Cover: job-76_cover.pdf / .docx / .txt
   - Email: job-76_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://jobs.lever.co/glide
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
