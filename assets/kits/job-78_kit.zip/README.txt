JobSearchSF — Easy Apply Kit
ID: job-78 — job-78
Company: San Francisco AIDS Foundation (Magnet/Strut)
Position: Lab Technician (Phlebotomist) — Per Diem (LIVE; $34-37/hr)
Location: 470 Castro Street, San Francisco, CA 94114 (per official posting; may travel to other SFAF sites)
Match Score: 58%
Status: recently-posted
Status Note: Live on official Greenhouse board (checked Sept 9, 2026) — re-verify job 5219589008 is open before applying.
Flag: Per diem (variable hours) — stepping-in path while FT reqs fill; same certification requirements as the FT posting.
Verification: LIVE official Greenhouse posting (job 5219589008) fetched Sept 9, 2026 — Per Diem variant of the 470 Castro St Lab Technician role, $34-37/hr

Official Site: https://job-boards.greenhouse.io/sfaf/jobs/5219589008
Direct Apply (official, no recruiter): #
Channel: Official SFAF Greenhouse board (direct nonprofit employer)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-78_resume.pdf / .docx / .txt
   - Cover: job-78_cover.pdf / .docx / .txt
   - Email: job-78_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://job-boards.greenhouse.io/sfaf/jobs/5219589008
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
