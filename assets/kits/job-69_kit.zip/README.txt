JobSearchSF — Easy Apply Kit
ID: job-69 — job-69
Company: NCIRE — The Veterans Health Research Institute (SF VA affiliate)
Position: Staff Research Associate II (STAFF001526) — Research support with data workflows (LIVE)
Location: 4150 Clement Street, San Francisco, CA 94121 (Lincoln Park — SF VA campus area)
Match Score: 74%
Status: recently-posted
Status Note: Live posting STAFF001526 on official NCIRE careers (checked Sept 9, 2026, $25.24-$40.60/hr) — re-verify req is open, then apply via the official board.
Flag: None — no irregularity found at audit; re-verify live before applying
Verification: LIVE posting STAFF001526 (4150 Clement St, Lincoln Park, $25.24-$40.60/hr) confirmed on official NCIRE careers channel (Ultrio) Sept 9, 2026

Official Site: https://www.ncire.org/careers
Direct Apply (official, no recruiter): #
Channel: Official NCIRE careers portal (direct nonprofit employer — see also job-11/12)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-69_resume.pdf / .docx / .txt
   - Cover: job-69_cover.pdf / .docx / .txt
   - Email: job-69_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://www.ncire.org/careers
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
