JobSearchSF — Easy Apply Kit
ID: job-23 — job-23
Company: City College of San Francisco — Sciences / Laboratory Support
Position: Laboratory Technician / Technical Instructional Aide (science labs, Ocean Campus)
Location: 50 Frida Kahlo Way (Ocean Campus), San Francisco, CA 94112
Match Score: 78%
Status: recently-posted
Status Note: jobs.ccsf.edu live with 32 openings including '2439 Technical Instructional Assist, Laboratory/Storeroom Manager' (checked Sept 9, 2026) — lab-support hiring is active; science-lab postings recur.
Flag: The live lab-manager posting seen is in the Art Department — search 'Laboratory' for science-lab roles specifically.
Verification: Official jobs.ccsf.edu portal live (32 openings incl. Laboratory/Storeroom Manager) verified

Official Site: https://www.ccsf.edu/about-ccsf/administration/human-resources/jobs-ccsf
Direct Apply (official, no recruiter): #
Channel: Official CCSF HR employment portal (direct)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-23_resume.pdf / .docx / .txt
   - Cover: job-23_cover.pdf / .docx / .txt
   - Email: job-23_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://www.ccsf.edu/about-ccsf/administration/human-resources/jobs-ccsf
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
