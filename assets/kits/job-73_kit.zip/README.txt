JobSearchSF — Easy Apply Kit
ID: job-73 — job-73
Company: Anthropic (public benefit corp) — AI for science, Life Sciences team
Position: Research Associate, Biology - entry-level bench scientist (molecular biology + biochemistry; WITHDRAWN 2026-09-09, watch for repost)
Location: 548 Market Street (SF office), San Francisco, CA 94104
Match Score: 76%
Status: monitor
Status Note: CLOSED at 2026-09-09 audit: job-boards.greenhouse.io/anthropic/jobs/5285248008 now serves "The job you are looking for is no longer open" (verified by fetching the official board, which redirects with ?error=true). Was listed LIVE in Pass 4 - that claim is corrected here.
Flag: Irregularity found on this pass: the posting was live in Pass 4 and withdrawn before Pass 6. Anthropic re-posts bench roles on the same board, so keep the alert; do not apply to a cached or aggregator copy of this req.
Verification: LIVE official Greenhouse posting (job 5285248008) fetched Sept 9, 2026 — full description + application form on official board; anthropic.com/careers official; 548 Market St SF office corroborated

Official Site: https://job-boards.greenhouse.io/anthropic/jobs/5285248008
Direct Apply (official, no recruiter): #
Channel: Official Anthropic Greenhouse board (direct employer; careers hub anthropic.com/careers)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-73_resume.pdf / .docx / .txt
   - Cover: job-73_cover.pdf / .docx / .txt
   - Email: job-73_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://job-boards.greenhouse.io/anthropic/jobs/5285248008
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
