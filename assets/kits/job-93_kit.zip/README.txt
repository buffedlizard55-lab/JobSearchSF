Easy Apply Kit — job-93 — NCIRE — The Veterans Health Research Institute — Nayak Lab (SF VA) — Staff Research Associate I — Gut microbiome, rheumatic disease, analytical chemistry, mass spec metabolomics, anaerobic micro (LIVE b5d49cdc)
Generated: Pass 8 True 1-Click Easy Apply — September 12, 2026

Official Site: https://www.ncire.org/careers
Direct Apply (verified, official ATS only): https://recruiting.ultipro.com/NOR1032NCIRE/JobBoard/82cac330-9aa5-417d-9b64-568d383f4ea0/OpportunityDetail/b5d49cdc-8f2e-4f1e-9b5a-3c2d1e4f5a6b
Channel: Official NCIRE UltiPro board (direct nonprofit employer)
Match Score: 84%
Flag: No irregularity

CONTENTS:
- Resume PDF/DOCX/TXT tailored to this job
- Cover PDF/DOCX/TXT tailored
- Email TXT intro
- Tailored screening answers (honest No where needed)
- Brian_Profile.json + Screening_Answers.txt autofill vault
- This README with direct links

1-CLICK FLOW:
1. Download this ZIP (already done)
2. Open Direct Apply link above (official ATS: Greenhouse, Lever, Ashby, Workday, SmartRecruiters, UltiPro, AP Recruit)
3. Upload Resume DOCX (Workday) or PDF (Greenhouse/Lever/Ashby) + Cover
4. Copy-paste personal info from Screening_Answers.txt or Brian_Profile.json
5. Answer screening from job-93_screening.txt — honest No + what you HAVE done (HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records)
6. Submit + save confirmation number/date in tracker on subpage

ATS NOTES:
- Workday: prefers DOCX <5MB, autofill draft must review, cannot edit after submit
- Greenhouse: prefers text-based PDF, single-column, name top line, Skills comma-separated, Month YYYY
- Lever: custom Qs, forgiving PDF, concise free-text
- Ashby: light burden
- SmartRecruiters: City REF60430L deadline 11:59 PM PST eligible 12mo
- UltiPro: b5d49cdc site (NCIRE)
- AP Recruit: JPFxxxxx UCSF postings
- ATS does NOT detect autofill — indistinguishable from typed

No hallucinations — all docs use real resume facts only. Re-verify live posting before applying (postings rotate daily).
