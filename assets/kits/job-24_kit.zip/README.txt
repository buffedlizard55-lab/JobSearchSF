JobSearchSF — Easy Apply Kit
ID: job-24 — job-24
Company: California Academy of Sciences — Institute for Biodiversity Science (IBSS)
Position: Research Lab / Collections Support (Center for Comparative Genomics, specimen prep)
Location: 55 Music Concourse Drive, Golden Gate Park, San Francisco, CA 94118
Match Score: 68%
Status: monitor
Status Note: Greenhouse board live with 10 jobs (checked Sept 9, 2026) but currently senior-heavy (curators, managers); entry lab/collections support roles post periodically — set a job alert.
Flag: Current board is senior-heavy; entry roles are periodic — set Greenhouse job alert rather than expecting an immediate opening.
Verification: Official calacademy.org/careers → Greenhouse board live (10 jobs) + 55 Music Concourse verified

Official Site: https://www.calacademy.org/careers
Direct Apply (official, no recruiter): #
Channel: Official Greenhouse board (direct, linked from calacademy.org)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-24_resume.pdf / .docx / .txt
   - Cover: job-24_cover.pdf / .docx / .txt
   - Email: job-24_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://www.calacademy.org/careers
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
