JobSearchSF — Easy Apply Kit
ID: job-65 — job-65
Company: UCSF — Kamber Lab, Anatomy
Position: Junior/Assistant Specialist — Cancer immunology & CRISPR screening (JPF05697, open until filled)
Location: UCSF Parnassus Heights (Anatomy, 580 Parnassus Ave area), San Francisco, CA 94143
Match Score: 68%
Status: monitor
Status Note: Open-until-filled academic posting (first review date Aug 22, 2025 passed) — re-verify it is still listed on apprecruit.ucsf.edu before applying; late applications are considered while unfilled.
Flag: Rolling posting — initial review date has passed; confirm it is still open at apply time.
Verification: Posting JPF05697 on official apprecruit.ucsf.edu (open until filled — first review Aug 22, 2025; $53,100-$188,200 by rank; kamberlab.com official lab site)

Official Site: https://aprecruit.ucsf.edu/JPF05697
Direct Apply (official, no recruiter): #
Channel: Official UCSF academic recruit portal aprecruit.ucsf.edu (direct)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-65_resume.pdf / .docx / .txt
   - Cover: job-65_cover.pdf / .docx / .txt
   - Email: job-65_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://aprecruit.ucsf.edu/JPF05697
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
