JobSearchSF — Easy Apply Kit
ID: job-75 — job-75
Company: Parallel Bio — human-first drug discovery + patient biobank
Position: Research Associate, Biobanking — human tissue sample processing, LIMS, QC (LIVE; $70-85K)
Location: San Francisco, CA 94110 (Mission — '100% onsite... San Francisco lab' per official posting; street address confirmed at interview)
Match Score: 76%
Status: recently-posted
Status Note: Live on official Ashby board (checked Sept 9, 2026) — re-verify before applying; occasional weekend/off-hours work for time-sensitive clinical samples.
Flag: Street address not published (SF 94110 per official posting) — confirm at interview; cold-chain + consent/IRB/HIPAA documentation is part of the role.
Verification: LIVE official Ashby posting fetched Sept 9, 2026 (jobs.ashbyhq.com/parallel-bio) — '100% onsite role based at our San Francisco lab', SF 94110; parallel.bio official site verified

Official Site: https://jobs.ashbyhq.com/parallel-bio/3ceab0ea-308b-4518-8939-3c011c624c5b
Direct Apply (official, no recruiter): #
Channel: Official Parallel Bio Ashby board (direct venture-backed employer)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-75_resume.pdf / .docx / .txt
   - Cover: job-75_cover.pdf / .docx / .txt
   - Email: job-75_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://jobs.ashbyhq.com/parallel-bio/3ceab0ea-308b-4518-8939-3c011c624c5b
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
