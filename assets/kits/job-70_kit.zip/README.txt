JobSearchSF — Easy Apply Kit
ID: job-70 — job-70
Company: Gladstone Institutes — Marson Lab (Institute of Genomic Immunology)
Position: Research Associate (In-Vivo) — Mouse models of immunotherapy + colony management (LIVE)
Location: 535 Mission Street / 520 Beach Street (Mission Bay), San Francisco, CA 94158
Match Score: 60%
Status: recently-posted
Status Note: Live on official gladstone.wd5.myworkdayjobs.com (checked Sept 9, 2026, $28-33/hr) — re-verify req is open, then apply via the official board.
Flag: Mouse colony work is central (breeding, injections, genotyping, euthanasia).
Verification: LIVE 'Research Associate (In-Vivo) - Marson Lab' + 'RA I/II - Marson Lab' confirmed on official gladstone.wd5.myworkdayjobs.com (SF, $28-33/hr) Sept 9, 2026; opportunities.ucsf.edu mirror

Official Site: https://gladstone.wd5.myworkdayjobs.com/en-US/careers
Direct Apply (official, no recruiter): #
Channel: Official Gladstone Institutes Workday portal (direct nonprofit employer — new live Marson-Lab posting; see also job-04/05/06)

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-70_resume.pdf / .docx / .txt
   - Cover: job-70_cover.pdf / .docx / .txt
   - Email: job-70_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://gladstone.wd5.myworkdayjobs.com/en-US/careers
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
