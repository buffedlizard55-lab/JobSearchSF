JobSearchSF — Easy Apply Kit
ID: job-119 — job-119
Company: Addition Therapeutics, Inc. (in vivo cell therapy)
Position: Research Associate, Quality Control (South San Francisco)
Location: South San Francisco, CA (per the employer's own board - not San Francisco)
Match Score: 80%
Status: monitor
Status Note: Real, currently live, direct-hire posting verified 2026-09-09 - excluded from the target list only because every requisition on this employer's board is South San Francisco, outside the SF-only rule. If you ever widen the radius, this is a top alternate.
Flag: Location rule - South San Francisco is a separate city on the peninsula, not an N Judah commute. Listed for completeness, not recommended under current constraints.
Verification: Addition Therapeutics official Greenhouse board API listing boards-api.greenhouse.io/v1/boards/additiontherapeutics/jobs fetched 2026-09-09: 7 live requisitions, incl. req 60 'RA, Quality Control' (job 5216310007), location 'South San Francisco', published 2026-08-20

Official Site: https://job-boards.greenhouse.io/additiontherapeutics
Direct Apply (official, no recruiter): #
Channel: Official employer board (Greenhouse), direct hire - no recruiter

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-119_resume.pdf / .docx / .txt
   - Cover: job-119_cover.pdf / .docx / .txt
   - Email: job-119_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://job-boards.greenhouse.io/additiontherapeutics
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
