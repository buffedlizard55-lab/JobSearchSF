JobSearchSF — Easy Apply Kit
ID: job-118 — job-118
Company: Plasmidsaurus, Inc. (DNA/RNA sequencing services)
Position: Lab Technician | San Francisco (library prep and sequencing instruments)
Location: Posting lists San Francisco, but the body says 'This is an in-office in our South San Francisco, CA location' and hours are Tue-Sat 7pm-3am
Match Score: 84%
Status: monitor
Status Note: Live posting at audit (2026-09-09, posted 2026-08-26) but kept as a documented alternate rather than a target for two reasons: worksite is South San Francisco, and the schedule is Tue-Sat 7pm-3am.
Flag: IRREGULARITY - title/location field says 'San Francisco' while the description sets the office in South San Francisco and an overnight shift. Confirm worksite and hours with the employer before applying.
Verification: Official Ashby posting 1dea5cc2-a669-4f22-8eaa-8e569745bd58 fetched 2026-09-09: location field 'San Francisco', on-site, full time, $72.5K-$82.5K plus equity, posted 2026-08-26; body text read in full

Official Site: https://plasmidsaurus.com
Direct Apply (official, no recruiter): #
Channel: Official employer board (Ashby), direct hire - no recruiter, no agency

HOW TO APPLY IN 3 CLICKS (no manual typing needed):
1. Open the Direct Apply link above (official employer ATS only). Verify the posting is still live — postings rotate daily.
2. Upload Resume PDF (or DOCX if portal requires DOCX) and Cover Letter PDF from this ZIP.
   - Resume: job-118_resume.pdf / .docx / .txt
   - Cover: job-118_cover.pdf / .docx / .txt
   - Email: job-118_email.txt (use if portal has message box or if official contact listed)
3. Copy-paste personal info from assets/profile/Screening_Answers.txt (or Brian_Profile.json) into the form. Answer screening honestly (say No if you haven't done a technique, mention what you HAVE done: HPLC, NMR, UV-Vis, chromatography, sample prep, GLP, QC, electronic records). Submit directly, save confirmation number in tracker on job page.

AUTOFILL VAULT:
- Profile JSON: assets/profile/Brian_Profile.json
- Screening answers: assets/profile/Screening_Answers.txt
- Master resume: assets/resume/Brian_Chemistry_Resume.pdf
- Master cover: assets/cover/Brian_Cover_Letter_Base.pdf

VERIFICATION FOR MANUAL REVIEW:
- Official Link: https://plasmidsaurus.com
- Direct Apply Link: #
- All sources are in data.js for this job. See job page for full source list.
- Apply only via official domain (Greenhouse job-boards.greenhouse.io, Lever jobs.lever.co, Ashby jobs.ashbyhq.com, Workday, SmartRecruiters careers.sf.gov, UltiPro recruiting.ultipro.com, AP Recruit aprecruit.ucsf.edu). Never via aggregator (Indeed/ZipRecruiter) except Anresco's own Indeed company page which is employer-managed.

ANTI-SCAM CHECK:
- No payment, no fee, no SSN/banking before interview.
- Reply should come from employer's own email domain.
- If posting says "South San Francisco" but title says "San Francisco" (e.g., Plasmidsaurus), confirm worksite before applying — flagged in this dataset.

Generated: 2026-09-12 (Pass 7 Easy Apply)
Branch: arena/01a097c2-jobsearchsf
